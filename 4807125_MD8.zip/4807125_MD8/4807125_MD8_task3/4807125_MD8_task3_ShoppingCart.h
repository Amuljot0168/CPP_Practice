#ifndef SHOPPINGCART_H
#define SHOPPINGCART_H

#include <string>
class ShoppingCart
{
private:
    int cartID;
    int averageOrderSize;
    int currentItems;
    std::string customerName;
    double totalCost;

public:
    // Constructor to initalizes all data members
    ShoppingCart(int cartID_, int averageOrderSize_, const std::string &customerName_);

    // Simulates the removal of item from cart
    void removeItem();

    // Simulates the addition of items
    void addItem(int quantity, double price);

    // Displays the shopping details
    void displayDetails() const;

    // Applies the discount
    void applyDiscount(double discountPercentage);

    // Accessors
    int getCurrentItems() const;
    double getTotalCost() const;
    int getAverageOrderSize() const;
};

#endif // SHOPPINGCART_H