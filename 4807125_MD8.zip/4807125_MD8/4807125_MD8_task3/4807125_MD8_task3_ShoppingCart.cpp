#include "4807125_MD8_task3_ShoppingCart.h"
#include <iostream>

#include <iostream>

// Constructor
ShoppingCart::ShoppingCart(int cartID_, int averageOrderSize_, const std::string &customerName_)
    : cartID(cartID_), averageOrderSize(averageOrderSize_), customerName(customerName_), currentItems(0), totalCost(0.0) {}

// Simulate item removal
void ShoppingCart::removeItem()
{
    int removed = std::min(averageOrderSize, currentItems);
    currentItems -= removed;
    std::cout << "Removed " << removed << " items from cart ID " << cartID << ".\n";
}

// Add items to the cart
void ShoppingCart::addItem(int quantity, double price)
{
    currentItems += quantity;
    totalCost += quantity * price;
}

// Display cart details
void ShoppingCart::displayDetails() const
{
    std::cout << "Cart ID: " << cartID << "\n"
              << "Customer: " << customerName << "\n"
              << "Average Order Size: " << averageOrderSize << "\n"
              << "Current Items: " << currentItems << "\n"
              << "Total Cost: $" << totalCost << "\n";
}

// Apply discount to total cost
void ShoppingCart::applyDiscount(double discountPercentage)
{
    double discountAmount = totalCost * (discountPercentage / 100.0);
    totalCost -= discountAmount;
    std::cout << "Applied " << discountPercentage << "% discount. New total: $" << totalCost << "\n";
}

// Accessors
int ShoppingCart::getCurrentItems() const
{
    return currentItems;
}

double ShoppingCart::getTotalCost() const
{
    return totalCost;
}

int ShoppingCart::getAverageOrderSize() const
{
    return averageOrderSize;
}