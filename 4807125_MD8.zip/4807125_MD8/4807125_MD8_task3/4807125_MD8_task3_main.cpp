#include <iostream>
#include <thread>
#include "4807125_MD8_task3_ShoppingCartManagementSystem.h"
int main()
{
    // Step 1: Create system
    ShoppingCartManagementSystem system;

    // Step 2: Create carts with different average order sizes
    ShoppingCart cart1(101, 5, "Alice");
    ShoppingCart cart2(102, 6, "Bob");
    ShoppingCart cart3(103, 10, "Charlie");

    // Add initial items to each cart
    cart1.addItem(10, 20.0);
    cart2.addItem(12, 15.0);
    cart3.addItem(20, 10.0);

    // Step 3: Add carts to system
    system.addCart(cart1);
    system.addCart(cart2);
    system.addCart(cart3);

    // Step 6: Repeat for 3 iterations
    for (int i = 0; i < 3; ++i)
    {
        std::cout << "\n--- Iteration " << i + 1 << " ---\n";

        // Step 4: Create threads
        std::thread removalThread(&ShoppingCartManagementSystem::simulateItemRemoval, &system);
        std::thread restockThread([&system]()
                                  {
            std::this_thread::sleep_for(std::chrono::seconds(2)); // simulate delay
            system.restockItems(); });

        // Step 5: Join threads
        removalThread.join();
        restockThread.join();

        // Step 7–9: Display system status
        system.displayStockLevel();
        system.displayTotalRevenue();
        system.generateReport();
    }

    return 0;
}
