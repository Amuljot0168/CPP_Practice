#include "4807125_MD8_task3_ShoppingCartManagementSystem.h"
#include <iostream>
#include <mutex>

// Constructor
ShoppingCartManagementSystem::ShoppingCartManagementSystem()
{
    stockLevel = 100;
    totalRevenue = 0.0;
}

// Add a cart
void ShoppingCartManagementSystem::addCart(ShoppingCart cart)
{
    carts.push_back(cart);
}

// Simulate item removal
void ShoppingCartManagementSystem::simulateItemRemoval()
{
    std::lock_guard<std::mutex> lock(mtx);
    for (auto &cart : carts)
    {
        cart.removeItem();
        totalRevenue += cart.getTotalCost();
    }
}

// Restock items
void ShoppingCartManagementSystem::restockItems()
{
    std::lock_guard<std::mutex> lock(mtx);
    stockLevel += 50;
    std::cout << "Restocked 50 items. New stock level: " << stockLevel << "\n";
}

// Display stock level
void ShoppingCartManagementSystem::displayStockLevel()
{
    std::lock_guard<std::mutex> lock(mtx);
    std::cout << "Current stock level: " << stockLevel << "\n";
}

// Display total revenue
void ShoppingCartManagementSystem::displayTotalRevenue()
{
    std::lock_guard<std::mutex> lock(mtx);
    std::cout << "Total revenue: $" << totalRevenue << "\n";
}

// Generate report
void ShoppingCartManagementSystem::generateReport()
{
    std::lock_guard<std::mutex> lock(mtx);

    int totalItems = 0;
    double totalCost = 0.0;
    int totalOrderSize = 0;

    for (const auto &cart : carts)
    {
        totalItems += cart.getCurrentItems();
        totalCost += cart.getTotalCost();
        totalOrderSize += cart.getAverageOrderSize();
    }

    std::cout << "\n--- Shopping Cart Report ---\n";
    std::cout << "Total items sold: " << totalItems << "\n";
    std::cout << "Total revenue: $" << totalCost << "\n";
    std::cout << "Average order size: " << (carts.empty() ? 0 : totalOrderSize / carts.size()) << "\n";
}