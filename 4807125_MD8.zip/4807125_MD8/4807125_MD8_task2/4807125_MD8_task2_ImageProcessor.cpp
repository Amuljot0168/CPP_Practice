#include "4807125_MD8_task2_ImageProcessor.h"
#include <iostream>

// Constructor to initializes image with given number of pixels
ImageProcessor::ImageProcessor(int numPixels)
{
    pixels.resize(numPixels);
    for (int i = 0; i < numPixels; i++)
    {
        pixels[i] = i; // Sample Initialization
    }
}

// Method to print a subset of pixels for verification
void ImageProcessor::printResult(int count) const
{
    std::cout << "First " << count << " pixels :\n";
    for (int i = 0; i < count && i < pixels.size(); ++i)
    {
        std::cout << pixels[i] << " ";
    }
    std::cout << "\n";
}

// Parallel Processing
// Simulates filtering by modifying pixel values
void ImageProcessor::applyFilterToRegion(int start, int end, const std::string &filterName)
{
    for (int i = start; i < end; ++i)
    {
        if (filterName == "Grayscale")
        {
            pixels[i] = pixels[i] * 2;
        }
    }
}
// Divide image and process in parallel
void ImageProcessor::processImageParallel(const std::string &filterName, int numThreads)
{
    std::vector<std::thread> threads;
    int regionSize = pixels.size() / numThreads;

    for (int t = 0; t < numThreads; ++t)
    {
        int start = t * regionSize;
        int end = (t == numThreads - 1) ? pixels.size() : start + regionSize;

        threads.emplace_back(&ImageProcessor::applyFilterToRegion, this, start, end, filterName);
    }

    for (auto &th : threads)
        th.join();
}