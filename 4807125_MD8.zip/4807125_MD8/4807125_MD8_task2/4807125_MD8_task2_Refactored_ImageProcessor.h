#ifndef IMAGEPROCESSOR_H
#define IMAGEPROCESSOR_H

#include <vector>
#include <string>
#include <mutex>
#include <thread>
#include <iostream>

class ImageProcessor
{
private:
    std::vector<int> pixels; // Stores image pixel data
    std::mutex mtx;          // Protects shared resources (e.g., std::cout)

public:
    // Constructor: initializes image with given number of pixels
    explicit ImageProcessor(int numPixels);

    // Set pixel data externally (optional for testing or custom input)
    void setPixels(const std::vector<int> &inputPixels);

    // Apply filter to a region of the image
    void applyFilterToRegion(int start, int end, const std::string &filterName);

    // Process the image in parallel using multiple threads
    void processImageParallel(const std::string &filterName, int numThreads);

    // Print first N pixels for verification
    void printFirstPixels(int count) const;

    // Accessor for full pixel data (optional)
    const std::vector<int> &getPixels() const;
};

#endif // IMAGEPROCESSOR_H