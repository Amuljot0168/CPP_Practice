#include "4807125_MD8_task2_Refactored_ImageProcessor.h"
#include <iostream>
#include <string>
#include <mutex>

// Constructor: initializes image with sample pixel values
ImageProcessor::ImageProcessor(int numPixels)
{
    pixels.resize(numPixels);
    for (int i = 0; i < numPixels; ++i)
    {
        pixels[i] = i; // Sample initialization
    }
}

// Optional: Set pixel data externally
void ImageProcessor::setPixels(const std::vector<int> &inputPixels)
{
    pixels = inputPixels;
}

// Print first N pixels for verification
void ImageProcessor::printFirstPixels(int count) const
{
    std::cout << "First " << count << " pixels:\n";
    for (int i = 0; i < count && i < pixels.size(); ++i)
    {
        std::cout << pixels[i] << " ";
    }
    std::cout << "\n";
}

// Apply filter to a region of the image
void ImageProcessor::applyFilterToRegion(int start, int end, const std::string &filterName)
{
    for (int i = start; i < end; ++i)
    {
        if (filterName == "Grayscale")
        {
            pixels[i] = pixels[i] * 2; // Example grayscale logic
        }
        // Add more filters here if needed
    }

    // Optional: log thread activity
    std::lock_guard<std::mutex> lock(mtx);
    std::cout << "Processed region [" << start << ", " << end << ") with filter: " << filterName << "\n";
}

// Divide image and process in parallel
void ImageProcessor::processImageParallel(const std::string &filterName, int numThreads)
{
    std::vector<std::thread> threads;
    int regionSize = pixels.size() / numThreads;

    for (int t = 0; t < numThreads; ++t)
    {
        int start = t * regionSize;
        int end = (t == numThreads - 1) ? pixels.size() : start + regionSize;

        threads.emplace_back(&ImageProcessor::applyFilterToRegion, this, start, end, filterName);
    }

    for (auto &th : threads)
    {
        th.join();
    }
}

// Optional: Accessor for full pixel data
const std::vector<int> &ImageProcessor::getPixels() const
{
    return pixels;
}
#include "4807125_MD8_task2_ImageProcessor.h"
#include <iostream>
#include <string>
#include <mutex>

    // Constructor: initializes image with sample pixel values
    ImageProcessor::ImageProcessor(int numPixels)
{
    pixels.resize(numPixels);
    for (int i = 0; i < numPixels; ++i)
    {
        pixels[i] = i; // Sample initialization
    }
}

// Optional: Set pixel data externally
void ImageProcessor::setPixels(const std::vector<int> &inputPixels)
{
    pixels = inputPixels;
}

// Print first N pixels for verification
void ImageProcessor::printFirstPixels(int count) const
{
    std::cout << "First " << count << " pixels:\n";
    for (int i = 0; i < count && i < pixels.size(); ++i)
    {
        std::cout << pixels[i] << " ";
    }
    std::cout << "\n";
}

// Apply filter to a region of the image
void ImageProcessor::applyFilterToRegion(int start, int end, const std::string &filterName)
{
    for (int i = start; i < end; ++i)
    {
        if (filterName == "Grayscale")
        {
            pixels[i] = pixels[i] * 2; // Example grayscale logic
        }
        // Add more filters here if needed
    }

    // Optional: log thread activity
    std::lock_guard<std::mutex> lock(mtx);
    std::cout << "Processed region [" << start << ", " << end << ") with filter: " << filterName << "\n";
}

// Divide image and process in parallel
void ImageProcessor::processImageParallel(const std::string &filterName, int numThreads)
{
    std::vector<std::thread> threads;
    int regionSize = pixels.size() / numThreads;

    for (int t = 0; t < numThreads; ++t)
    {
        int start = t * regionSize;
        int end = (t == numThreads - 1) ? pixels.size() : start + regionSize;

        threads.emplace_back(&ImageProcessor::applyFilterToRegion, this, start, end, filterName);
    }

    for (auto &th : threads)
    {
        th.join();
    }
}

// Optional: Accessor for full pixel data
const std::vector<int> &ImageProcessor::getPixels() const
{
    return pixels;
}