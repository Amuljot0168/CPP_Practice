#include "4807125_MD8_task2_Refactored_ImageProcessor.h"
#include <string>

int main()
{
    ImageProcessor processor(1000);                 // Create image with 1000 pixels
    processor.processImageParallel("Grayscale", 4); // Use 4 threads
    processor.printFirstPixels(10);                 // Print first 10 pixels
    return 0;
}