#ifndef IMAGEPROCESSOR_H
#define IMAGEPROCESSOR_H

#include <vector>
#include <thread>

class ImageProcessor
{
private:
    std::vector<int> pixels;

public:
    // Constructor to initializes image with given number of pixels
    ImageProcessor(int num);

    // Method to print a subset of pixels for verification
    void printResult(int count) const;

    // Parallel Processing
    // Simulates filtering by modifying pixel values
    void applyFilterToRegion(int start, int end, const std::string &filterName);

    // Divide image and process in parallel
    void processImageParallel(const std::string &filterName, int numThreads);
};

#endif // IMAGEPROCESSOR_H