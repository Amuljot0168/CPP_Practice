#include "4807125_MD8_task1_MatrixMultiplier.h"
#include <iostream>
// Constructor initialises with given dimensions
MatrixMultiplier::MatrixMultiplier(int rowsA_, int colsA_, int rowsB_, int colsB_) : rowsA(rowsA_), colsA(colsA_), rowsB(rowsB_), colsB(colsB_)
{
    A.resize(rowsA, std::vector<int>(colsA));
    B.resize(rowsB, std::vector<int>(colsB));
    C.resize(rowsA, std::vector<int>(colsB));
}

// Multiply a single row of A with matrix B
void MatrixMultiplier::multiplyRow(int row)
{
    for (int i = 0; i < colsB; i++)
    {
        C[row][i] = 0;
        for (int j = 0; j < colsA; j++)
        {
            C[row][i] += A[row][j] * B[j][i];
        }
    }
}

// Parallel Multiplication
void MatrixMultiplier::multiplyParallel(int numThreads)
{
    std::vector<std::thread> threads;

    // Divide rows among threads
    for (int i = 0; i < numThreads; i++)
    {
        threads.emplace_back([=]()
                             {
            for(int j=i;j<rowsA;j+=numThreads){
                multiplyRow(j);
            } });
    }

    // Join Threads
    for (auto &th : threads)
    {
        th.join();
    }
}

// Method to print the matrix
void MatrixMultiplier::print() const
{
    std::cout << "\nMatrix: \n";
    for (const auto &row : C)
    {
        for (auto &val : row)
        {
            std::cout << val << " ";
        }
        std::cout << "\n";
    }
}