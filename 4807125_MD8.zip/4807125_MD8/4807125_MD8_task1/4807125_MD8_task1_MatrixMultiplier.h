#ifndef MATRIXMULTIPLIER
#define MATRIXMULTIPLIER

#include <vector>
#include <thread>

class MatrixMultiplier
{
public:
    std::vector<std::vector<int>> A, B, C;
    int rowsA, colsA, rowsB, colsB;

public:
    // Constructor initialises with given dimensions
    MatrixMultiplier(int rowsA_, int colsA_, int rowsB_, int colsB_);

    // Method to print the matrix
    void print() const;

    // Multiply a single row of A with matrix B
    void multiplyRow(int row);

    // Parallel Multiplication
    void multiplyParallel(int numThreads);
};

#endif // MATRIXMULTIPLIER
