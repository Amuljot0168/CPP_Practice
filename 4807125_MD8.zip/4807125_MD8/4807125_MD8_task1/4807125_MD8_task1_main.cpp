#include "4807125_MD8_MatrixMultiplier.h"
#include <iostream>

int main()
{
    // Create a MatrixMultiplier for two 3x3 matrices
    MatrixMultiplier mm(3, 3, 3, 3);

    // Manually fill matrix A
    mm.A = {
        {1, 2, 3},
        {4, 5, 6},
        {7, 8, 9}};

    // Manually fill matrix B
    mm.B = {
        {9, 8, 7},
        {6, 5, 4},
        {3, 2, 1}};

    // Perform parallel multiplication using 2 threads
    mm.multiplyParallel(2);

    // Print the resulting matrix C
    mm.print();

    return 0;
}