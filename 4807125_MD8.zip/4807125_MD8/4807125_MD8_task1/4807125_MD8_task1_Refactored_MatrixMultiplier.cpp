#include "4807125_MD8_task1_Refactored_MatrixMultiplier.h"
#include <iostream>

// Constructor: initializes matrix dimensions and allocates space
MatrixMultiplier::MatrixMultiplier(int rowsA_, int colsA_, int rowsB_, int colsB_)
    : rowsA(rowsA_), colsA(colsA_), rowsB(rowsB_), colsB(colsB_)
{
    A.resize(rowsA, std::vector<int>(colsA));
    B.resize(rowsB, std::vector<int>(colsB));
    C.resize(rowsA, std::vector<int>(colsB));
}

// Set matrix A from external input
void MatrixMultiplier::setMatrixA(const std::vector<std::vector<int>> &inputA)
{
    A = inputA;
}

// Set matrix B from external input
void MatrixMultiplier::setMatrixB(const std::vector<std::vector<int>> &inputB)
{
    B = inputB;
}

// Multiply a single row of A with matrix B
void MatrixMultiplier::multiplyRow(int row)
{
    for (int col = 0; col < colsB; ++col)
    {
        C[row][col] = 0;
        for (int k = 0; k < colsA; ++k)
        {
            C[row][col] += A[row][k] * B[k][col];
        }
    }
}

// Perform parallel multiplication using numThreads
void MatrixMultiplier::multiplyParallel(int numThreads)
{
    std::vector<std::thread> threads;

    for (int t = 0; t < numThreads; ++t)
    {
        threads.emplace_back([=]()
                             {
            for (int row = t; row < rowsA; row += numThreads) {
                multiplyRow(row);
            } });
    }

    for (auto &th : threads)
    {
        th.join();
    }
}

// Print the resulting matrix C
void MatrixMultiplier::printResult() const
{
    std::cout << "\nResult Matrix C:\n";
    for (const auto &row : C)
    {
        for (int val : row)
        {
            std::cout << val << " ";
        }
        std::cout << "\n";
    }
}

// Optional: Accessor for result matrix
const std::vector<std::vector<int>> &MatrixMultiplier::getResult() const
{
    return C;
}