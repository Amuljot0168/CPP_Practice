#ifndef MATRIXMULTIPLIER_H
#define MATRIXMULTIPLIER_H

#include <vector>
#include <thread>
#include <iostream> // For printing

class MatrixMultiplier
{
private:
    std::vector<std::vector<int>> A, B, C;
    int rowsA, colsA, rowsB, colsB;

public:
    // Constructor: initializes matrix dimensions and allocates space
    MatrixMultiplier(int rowsA_, int colsA_, int rowsB_, int colsB_);

    // Setters for input matrices
    void setMatrixA(const std::vector<std::vector<int>> &inputA);
    void setMatrixB(const std::vector<std::vector<int>> &inputB);

    // Multiply a single row of A with matrix B
    void multiplyRow(int row);

    // Perform parallel multiplication using specified number of threads
    void multiplyParallel(int numThreads);

    // Print the resulting matrix C
    void printResult() const;

    // Accessor for result matrix (optional)
    const std::vector<std::vector<int>> &getResult() const;
};

#endif // MATRIXMULTIPLIER_H