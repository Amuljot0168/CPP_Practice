#ifndef SENSOR_H
#define SENSOR_H

#include <string>

class Sensor
{
private:
    std::string name;
    int minValue;
    int maxValue;
    int numIterations;

public:
    Sensor(const std::string &name, int minValue, int maxValue, int numIterations);

    // Simulate sensor readings
    void run();
};

#endif // SENSOR_H