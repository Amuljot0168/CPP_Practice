#include "4807125_MD8_task4_Sensor.h"
#include <iostream>
#include <random>
#include <thread>
#include <chrono>

Sensor::Sensor(const std::string &name_, int minVal, int maxVal, int iterations)
    : name(name_), minValue(minVal), maxValue(maxVal), numIterations(iterations) {}

void Sensor::run()
{
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dist(minValue, maxValue);

    for (int i = 1; i <= numIterations; ++i)
    {
        int reading = dist(gen);
        std::cout << "[" << name << "] Reading " << i << ": " << reading << "\n";
        std::this_thread::sleep_for(std::chrono::milliseconds(500));
    }

    std::cout << "[" << name << "] finished simulation.\n";
}