#include "4807125_MD8_task4_Sensor.h"
#include <vector>
#include <thread>
#include <iostream>

int main()
{
    // Step 1: Create sensors
    std::vector<Sensor> sensors = {
        Sensor("Speed", 0, 200, 5),
        Sensor("Temperature", -20, 50, 5),
        Sensor("Fuel", 0, 100, 5),
        Sensor("GPS", 0, 100, 5)};

    // Step 2: Create threads
    std::vector<std::thread> threads;
    for (auto &sensor : sensors)
    {
        threads.emplace_back(&Sensor::run, &sensor);
    }

    // Step 3: Join threads
    for (auto &t : threads)
    {
        t.join();
    }

    // Step 4: Final message
    std::cout << "\nAll sensors finished simulation.\n";

    return 0;
}